-- Lua 5.3
-- Title: Grand Theft Auto: San Andreas - SLUS-20946 (USA) v3.00
-- Trophies version: 1.00
-- Author: Nicola Salmoria
-- Date: October 29, 2015

-- Changelog:
-- v0.4 20151029
-- - fixed bug #9076. Trophy 24 now triggers when a sex scene ends.


require( "ee-gpr-alias" ) -- you can access EE GPR by alias (gpr.a0 / gpr["a0"])

apiRequest(0.1)	-- request version 0.1 API. Calling apiRequest() is mandatory.

local eeObj		= getEEObject()
local emuObj	= getEmuObject()
local trophyObj	= getTrophyObject()


local TROPHY_GETTING_STARTED				=  1
local TROPHY_REPRESENT						=  2
local TROPHY_THE_END_OF_THE_LINE			=  3
local TROPHY_HUSTLE_SOME					=  4
local TROPHY_A_LEGITIMATE_BUSINESS			=  5
local TROPHY_THE_AMERICAN_DREAM				=  6
local TROPHY_GET_A_PUMP						=  7
local TROPHY_PAY_N_SPRAY					=  8
local TROPHY_BIKE_OR_BIKER					=  9
local TROPHY_BEAT_THE_COCK					= 10
local TROPHY_METROSEXUAL					= 11
local TROPHY_SCHOOLS_OUT					= 12
local TROPHY_SERIAL_OFFENDER				= 13
local TROPHY_FREIGHT_DATE					= 14
local TROPHY_HORROR_OF_THE_SANTA_MARIA		= 15
local TROPHY_ASSERT_YOURSELF_NEXT_TIME		= 16
local TROPHY_WHAT_THE_CITY_NEEDS			= 17
local TROPHY_SAVIOR							= 18
local TROPHY_RESCUE_A_KITTEN_TOO			= 19
local TROPHY_YES_I_SPEAK_ENGLISH			= 20
local TROPHY_TIME_TO_KILL					= 21
local TROPHY_WHAT_HAPPENS_IN_LAS_VENTURAS	= 22
local TROPHY_ALL_DRESSED_UP_FOR_SAN_FIERRO	= 23
local TROPHY_HOME_RUN						= 24
local TROPHY_WHAT_ARE_THE_ODDS				= 25
local TROPHY_DOUBLE_OR_NOTHIN				= 26
local TROPHY_ASSASSIN						= 27
local TROPHY_ORIGINAL_GANGSTER				= 28
local TROPHY_THE_LOST_SANTOS_SLAYER			= 29
local TROPHY_PUBLIC_ENEMY_NO_1				= 30
local TROPHY_CHICK_MAGNET					= 31
local TROPHY_GROVE_STREET_WAR_LORD			= 32


-- to avoid spamming certain trophies
local trophy_awarded = {}



-- convert unsigned int to signed
local function asSigned(n)
	local MAXINT = 0x80000000
	return (n >= MAXINT and n - 2*MAXINT) or n
end


-- some constant addresses
local SCRIPT_SPACE_BASE			= 0x6b2770
local ADDRESS_PLAYER_PEDESTRIAN = 0x70a160
local STATS_FLOAT_BASE			= 0x802cf0
local STATS_INT_BASE			= 0x802c60

local STATID_FLOAT_FASHION_BUDGET					= 14
local STATID_FLOAT_PROPERTY_BUDGET					= 15
local STATID_FLOAT_SEX_APPEAL						= 25
local STATID_FLOAT_TATTOO_BUDGET					= 30
local STATID_FLOAT_HAIRDRESSING_BUDGET				= 31
local STATID_FLOAT_HEAVIEST_WEIGHT_ON_BENCH_PRESS	= 46
local STATID_FLOAT_HEAVIEST_WEIGHT_ON_DUMBBELLS		= 47
local STATID_FLOAT_TOTAL_RESPECT					= 64

local STATID_INT_PEOPLE_YOUVE_WASTED				= 121
local STATID_INT_TIMES_BUSTED						= 133
local STATID_INT_PASSENGERS_DROPPED_OFF				= 150
local STATID_INT_HIGHEST_VIGILANTE_MISSION_LEVEL	= 157
local STATID_INT_HIGHEST_PARAMEDIC_MISSION_LEVEL	= 158
local STATID_INT_HIGHEST_FIREFIGHTER_MISSION_LEVEL	= 159
local STATID_INT_TIMES_DROWNED						= 170
local STATID_INT_NUMBER_OF_TIMES_SCORED_WITH_A_GIRL	= 187
local STATID_INT_NUMBER_OF_VEHICLES_EXPORTED		= 213
local STATID_INT_TERRITORIES_HELD					= 236

local SCRIPT_VAR_GIRLFRIEND_FLAGS		= 394
local SCRIPT_VAR_ROULETTE_BET_ARRAY		= 8402
local SCRIPT_VAR_ROULETTE_PAYOUT		= 8554

local GP_OFFSET_HAS_PLAYER_CHEATED	= 6680


function unlockTrophyIfNotCheated(trophy_id)
	local gp = eeObj.GetGpr(gpr.gp)
	local cheated = eeObj.ReadMem32(gp + GP_OFFSET_HAS_PLAYER_CHEATED)
	
	if cheated == 0 or bToolingCheatsOn ~= nil then --make sure player isn't cheating unless there are tooling cheats
		trophyObj.Unlock(trophy_id)
	else
		print( string.format("CHEATED - TROPHY NOT UNLOCKED") )
	end
end


local H1 =	-- register name id of last completed mission
	function()
		local missionIdPtr = eeObj.GetGpr(gpr.a1)
		local missionId = eeObj.ReadMemStr(missionIdPtr)

		if missionId == "INTRO_1" then			-- "Big Smoke"
			local trophy_id = TROPHY_GETTING_STARTED
			--	print( string.format("trophy_id=%d", trophy_id) )
			unlockTrophyIfNotCheated(trophy_id)
		elseif missionId == "LA1FIN2" then	-- "The Green Sabre"
			local trophy_id = TROPHY_ALL_DRESSED_UP_FOR_SAN_FIERRO
			--	print( string.format("trophy_id=%d", trophy_id) )
			unlockTrophyIfNotCheated(trophy_id)
		elseif missionId == "SYND_7" then	-- "Yay Ka-Boom-Boom"
			local trophy_id = TROPHY_WHAT_HAPPENS_IN_LAS_VENTURAS
			--	print( string.format("trophy_id=%d", trophy_id) )
			unlockTrophyIfNotCheated(trophy_id)
		elseif	missionId == "BMX" or		-- "BMX" (BMX challenge)
				missionId == "NRG500" then	-- "NRG-500" (NRG-500 challenge)
			local trophy_id = TROPHY_BIKE_OR_BIKER
			--	print( string.format("trophy_id=%d", trophy_id) )
			unlockTrophyIfNotCheated(trophy_id)
		elseif		missionId == "FAR_1" or		-- "Back to School"
					missionId == "DESERT5" then	-- "Learning to Fly"
			local trophy_id = TROPHY_SCHOOLS_OUT
			--	print( string.format("trophy_id=%d", trophy_id) )
			unlockTrophyIfNotCheated(trophy_id)
		end
	end


local H2 =	-- increment float stat
	function()
		local newValue = eeObj.GetFpr(0)
		local increment = eeObj.GetFpr(20)
		local address = eeObj.GetGpr(gpr.v0)
		local offset = address - STATS_FLOAT_BASE
		local statId = math.floor(offset / 4)

		if		statId == STATID_FLOAT_FASHION_BUDGET or
				statId == STATID_FLOAT_TATTOO_BUDGET or
				statId == STATID_FLOAT_HAIRDRESSING_BUDGET then
			-- the new value hasn't been stored yet so write it before checking the total budget
			eeObj.WriteMemFloat(address, newValue)

			local fashion = eeObj.ReadMemFloat(STATS_FLOAT_BASE + 4 * STATID_FLOAT_FASHION_BUDGET)
			local tattoo  = eeObj.ReadMemFloat(STATS_FLOAT_BASE + 4 * STATID_FLOAT_TATTOO_BUDGET)
			local hair    = eeObj.ReadMemFloat(STATS_FLOAT_BASE + 4 * STATID_FLOAT_HAIRDRESSING_BUDGET)

			local total = fashion + tattoo + hair
			
			if total >= 6969 then
				local trophy_id = TROPHY_METROSEXUAL
				--	print( string.format("trophy_id=%d", trophy_id) )
				unlockTrophyIfNotCheated(trophy_id)
			end
		elseif statId == STATID_FLOAT_PROPERTY_BUDGET then
			if newValue > 0 then
				local trophy_id = TROPHY_THE_AMERICAN_DREAM
				--	print( string.format("trophy_id=%d", trophy_id) )
				unlockTrophyIfNotCheated(trophy_id)
			end
		end
	end


local H3 =	-- increment int stat
	function()
		local newValue = eeObj.GetGpr(gpr.v0)
		local increment = eeObj.GetGpr(gpr.v1)
		local address = eeObj.GetGpr(gpr.a1)
		local offset = address - STATS_INT_BASE
		local statId = math.floor(offset / 4)

		if statId == STATID_INT_TIMES_DROWNED then
			if newValue >= 1 then
				local trophy_id = TROPHY_HORROR_OF_THE_SANTA_MARIA
				--	print( string.format("trophy_id=%d", trophy_id) )
				unlockTrophyIfNotCheated(trophy_id)
			end
		elseif statId == STATID_INT_TIMES_BUSTED then
			if newValue >= 50 then
				local trophy_id = TROPHY_SERIAL_OFFENDER
				--	print( string.format("trophy_id=%d", trophy_id) )
				unlockTrophyIfNotCheated(trophy_id)
			end
		elseif statId == STATID_INT_PASSENGERS_DROPPED_OFF then
			if newValue >= 50 then
				local trophy_id = TROPHY_YES_I_SPEAK_ENGLISH
				--	print( string.format("trophy_id=%d", trophy_id) )
				unlockTrophyIfNotCheated(trophy_id)
			end
		elseif statId == STATID_INT_PEOPLE_YOUVE_WASTED then
			if newValue >= 4000 then
				local trophy_id = TROPHY_THE_LOST_SANTOS_SLAYER
				if trophy_awarded[trophy_id] == nil then	-- avoid spamming after the first unlock of the session
					trophy_awarded[trophy_id] = true
					--	print( string.format("trophy_id=%d", trophy_id) )
					unlockTrophyIfNotCheated(trophy_id)
				end
			end
		elseif statId == STATID_INT_NUMBER_OF_VEHICLES_EXPORTED then
			if newValue >= 30 then
				local trophy_id = TROPHY_A_LEGITIMATE_BUSINESS
				--	print( string.format("trophy_id=%d", trophy_id) )
				unlockTrophyIfNotCheated(trophy_id)
			end
		end
	end


local H4 =	-- update sex appeal stat
	function()
		local newValue = eeObj.GetFpr(21)
		local oldValue = eeObj.ReadMemFloat(STATS_FLOAT_BASE + 4 * STATID_FLOAT_SEX_APPEAL)

		if		newValue > oldValue and
				newValue >= 1000 then
			local trophy_id = TROPHY_CHICK_MAGNET
			--	print( string.format("trophy_id=%d", trophy_id) )
			unlockTrophyIfNotCheated(trophy_id)
		end
	end


local H5 =	-- update respect stat
	function()
		local cachedNewValue = eeObj.GetGpr(gpr.v1)
		local cachedOldValue = eeObj.GetGpr(gpr.a0)

		if cachedNewValue ~= cachedOldValue then
			local newValue = eeObj.GetFpr(20)
			local oldValue = eeObj.ReadMemFloat(STATS_FLOAT_BASE + 4 * STATID_FLOAT_TOTAL_RESPECT)

			if		newValue > oldValue and
					newValue >= 1000 then
				local trophy_id = TROPHY_ORIGINAL_GANGSTER
				--	print( string.format("trophy_id=%d", trophy_id) )
				unlockTrophyIfNotCheated(trophy_id)
			end
		end
	end


local H6 =	-- scripting show big message
	function()
		local idPtr = eeObj.GetGpr(gpr.a1)
		local stringId = eeObj.ReadMemStr(idPtr)

		if stringId == "M_FAIL" then	-- "~r~MISSION FAILED!"
			local trophy_id = TROPHY_ASSERT_YOURSELF_NEXT_TIME
			--	print( string.format("trophy_id=%d", trophy_id) )
			unlockTrophyIfNotCheated(trophy_id)
		elseif	stringId == "BOAT_P2" or	-- "BOAT SCHOOL PASSED!"
				stringId == "BS_Z_7" then	-- "You have completed the Bike School.~n~~w~Motorbike Skill +"
			local trophy_id = TROPHY_SCHOOLS_OUT
			--	print( string.format("trophy_id=%d", trophy_id) )
			unlockTrophyIfNotCheated(trophy_id)
		end
	end


local H7 =	-- load cutscene data
	function()
		local idPtr = eeObj.GetGpr(gpr.a0)
		local stringId = eeObj.ReadMemStr(idPtr)

		if stringId == "EPILOG" then			-- end of "End of the Line"
			local trophy_id = TROPHY_THE_END_OF_THE_LINE
			--	print( string.format("trophy_id=%d", trophy_id) )
			unlockTrophyIfNotCheated(trophy_id)
		end
	end


local H8 =	-- buy item in shop
	function()
		local itemPtr = eeObj.GetGpr(gpr.v0)
		local itemTag = eeObj.ReadMemStr(itemPtr + 16)

		if		itemTag == "8SA" or			-- Back/Grove St. ($150)
				itemTag == "11GROVE" or		-- Stomach/Grove ($70)
				itemTag == "11GROV2" or		-- Stomach/Grove ($125)
				itemTag == "11GROV3" then	-- Stomach/Grove ($100)
			local trophy_id = TROPHY_REPRESENT
			--	print( string.format("trophy_id=%d", trophy_id) )
			unlockTrophyIfNotCheated(trophy_id)
		end
	end


local H9 =	-- update record stat
	function()
		local newValue = eeObj.GetFpr(12)
		local statId = eeObj.GetGpr(gpr.v0)
		-- NB the function would take the max of the newValue and the existing value

		if statId == STATID_INT_HIGHEST_VIGILANTE_MISSION_LEVEL then
			if newValue >= 12 then
				local trophy_id = TROPHY_WHAT_THE_CITY_NEEDS
				--	print( string.format("trophy_id=%d", trophy_id) )
				unlockTrophyIfNotCheated(trophy_id)
			end
		elseif statId == STATID_INT_HIGHEST_PARAMEDIC_MISSION_LEVEL then
			if newValue >= 12 then
				local trophy_id = TROPHY_SAVIOR
				--	print( string.format("trophy_id=%d", trophy_id) )
				unlockTrophyIfNotCheated(trophy_id)
			end
		elseif statId == STATID_INT_HIGHEST_FIREFIGHTER_MISSION_LEVEL then
			if newValue >= 12 then
				local trophy_id = TROPHY_RESCUE_A_KITTEN_TOO
				--	print( string.format("trophy_id=%d", trophy_id) )
				unlockTrophyIfNotCheated(trophy_id)
			end
		end
	end


local H10 =	-- set stat value
	function()
		local newValue = eeObj.GetFpr(12)
		local statId = eeObj.GetGpr(gpr.v0)

		if		statId == STATID_FLOAT_HEAVIEST_WEIGHT_ON_BENCH_PRESS or
				statId == STATID_FLOAT_HEAVIEST_WEIGHT_ON_DUMBBELLS then
			if newValue > 0 then
				local trophy_id = TROPHY_GET_A_PUMP
				--	print( string.format("trophy_id=%d", trophy_id) )
				unlockTrophyIfNotCheated(trophy_id)
			end
		end
	end


local H11 =	-- trigger garage message
	function()
		local idPtr = eeObj.GetGpr(gpr.a0)
		local stringId = eeObj.ReadMemStr(idPtr)

		if stringId == "GA_2" then	-- New engine and paint job: $100~n~Cops wont recognize you!
			local trophy_id = TROPHY_PAY_N_SPRAY
			--	print( string.format("trophy_id=%d", trophy_id) )
			unlockTrophyIfNotCheated(trophy_id)
		end
	end


local H12 =	-- check number of territories held
	function()
		local numHeld = eeObj.ReadMem32(STATS_INT_BASE + 4 * STATID_INT_TERRITORIES_HELD)

		if numHeld >= 30 then
			local trophy_id = TROPHY_GROVE_STREET_WAR_LORD
			--	print( string.format("trophy_id=%d", trophy_id) )
			unlockTrophyIfNotCheated(trophy_id)
		end
	end


local H13 =	-- scripting command 1114
	function()
		local idPtr = eeObj.GetGpr(gpr.sp) + 320
		local stringId = eeObj.ReadMemStr(idPtr)
		local number = eeObj.GetGpr(gpr.t0)

		if stringId == "PL_07" then			-- "You Win!~n~~w~$~1~"
			local trophy_id = TROPHY_HUSTLE_SOME
			-- the command is executed every frame so avoid spamming after the initial unlock
			if trophy_awarded[trophy_id] == nil then
				trophy_awarded[trophy_id] = true
				--	print( string.format("trophy_id=%d", trophy_id) )
				unlockTrophyIfNotCheated(trophy_id)
			end
		elseif	stringId == "YOUWIN" and	-- "WON: $~1~"
				number > 0 then				-- won
			local trophy_id = TROPHY_WHAT_ARE_THE_ODDS
			-- the command is executed every frame so avoid spamming after the initial unlock
			if trophy_awarded[trophy_id] == nil then
				trophy_awarded[trophy_id] = true
				--	print( string.format("trophy_id=%d", trophy_id) )
				unlockTrophyIfNotCheated(trophy_id)
			end
		end
	end


local H14 =	-- processing stealth kill
	function()
		local trophy_id = TROPHY_ASSASSIN
		--	print( string.format("trophy_id=%d", trophy_id) )
		unlockTrophyIfNotCheated(trophy_id)
	end


local function distanceSquared(x1, y1, x2, y2)
	local dx = x1 - x2
	local dy = y1 - y2
	return dx * dx + dy * dy
end

local function cityClosestToPoint(x, y)
	local dist1 = distanceSquared(x, y,  1670.0, -1137.0)	-- Los Santos
	local dist2 = distanceSquared(x, y, -1810.0,   884.0)	-- San Fierro
	local dist3 = distanceSquared(x, y,  2161.0,  2140.0)	-- Las Venturas

	if dist1 < dist2 then
		if dist1 < dist3 then
			return 1
		else
			return 3
		end
	else
		if dist2 < dist3 then
			return 2
		else
			return 3
		end
	end
end

local trainLastCity = 0	-- none

local H15 =	-- process a train
	function()
		local train = eeObj.GetGpr(gpr.a0)
		local player = eeObj.ReadMem32(ADDRESS_PLAYER_PEDESTRIAN)
		local isPlayerOnVehicle = (eeObj.ReadMem8(player + 1189) & 1)
		local playerVehicle = eeObj.ReadMem32(player + 1484)

		if isPlayerOnVehicle == 0 then		-- player not on any vehicle
			trainLastCity = 0
		elseif playerVehicle == train then	-- player on this train
			local coords = eeObj.ReadMem32(train + 20) + 48
			local x = eeObj.ReadMemFloat(coords + 0)
			local y = eeObj.ReadMemFloat(coords + 4)

			local city = cityClosestToPoint(x, y)

			if		trainLastCity ~= 0 and		-- player was already on train
					trainLastCity ~= city then	-- city changed
				local trophy_id = TROPHY_FREIGHT_DATE
				--	print( string.format("trophy_id=%d", trophy_id) )
				unlockTrophyIfNotCheated(trophy_id)
			end

			trainLastCity = city
		end
	end


local H16 =	-- handle script opcode 0x58
	function()
		local var1Addr = eeObj.GetGpr(gpr.s0)
		local var2Addr = eeObj.GetGpr(gpr.v0)

		local var1Offset = var1Addr - SCRIPT_SPACE_BASE
		local var2Offset = var2Addr - SCRIPT_SPACE_BASE

		local var1Id = math.floor(var1Offset / 4)
		local var2Id = math.floor(var2Offset / 4)

		if		var1Id == SCRIPT_VAR_ROULETTE_PAYOUT and	-- roulette payout
				(var2Id == SCRIPT_VAR_ROULETTE_BET_ARRAY+138 or var2Id == SCRIPT_VAR_ROULETTE_BET_ARRAY+139) then	-- bet on Red or Black
			local win = eeObj.ReadMem32(var2Addr)
			local scriptPtr = eeObj.GetGpr(gpr.s2)
			local maxWager = eeObj.ReadMem32(scriptPtr + 60 + 4*21)	-- local variable 21@

			if win == 2*maxWager then	-- bet everything on Red on Black
				local trophy_id = TROPHY_DOUBLE_OR_NOTHIN
				--	print( string.format("trophy_id=%d", trophy_id) )
				unlockTrophyIfNotCheated(trophy_id)
			end
		end
	end


local H17 =	-- achieve 6-star wanted level
	function()
		local trophy_id = TROPHY_PUBLIC_ENEMY_NO_1
		--	print( string.format("trophy_id=%d", trophy_id) )
		unlockTrophyIfNotCheated(trophy_id)
	end


local H18 =	-- scripting command 484
	function()
		local idPtr = eeObj.GetGpr(gpr.a1)
		local stringId = eeObj.ReadMemStr(idPtr)

		if stringId == "TRAI1" then			-- "You have been awarded with $~1~"
			local trophy_id = TROPHY_BEAT_THE_COCK
			--	print( string.format("trophy_id=%d", trophy_id) )
			unlockTrophyIfNotCheated(trophy_id)
		end
	end


local H19 =	-- scripting command 2234
	function()
		local bitNum = eeObj.GetGpr(gpr.a1)

		local varAddr = eeObj.GetGpr(gpr.s0)
		local varOffset = varAddr - SCRIPT_SPACE_BASE
		local varId = math.floor(varOffset / 4)

		if		varId == SCRIPT_VAR_GIRLFRIEND_FLAGS and	-- girlfriend related flags
				bitNum == 4 then							-- had sex
			local trophy_id = TROPHY_HOME_RUN
			--	print( string.format("trophy_id=%d", trophy_id) )
			unlockTrophyIfNotCheated(trophy_id)
		end
	end


local O1H1 =	-- end of credits
	function()
		local trophy_id = TROPHY_TIME_TO_KILL
		--	print( string.format("trophy_id=%d", trophy_id) )
		unlockTrophyIfNotCheated(trophy_id)
	end




-- register hooks
local hook1  = eeObj.AddHook(0x310128, 0x27a501a0, H1)	-- <CRunningScript::ProcessCommands700To799(int)>:
local hook2  = eeObj.AddHook(0x2d2b8c, 0x46140000, H2)	-- <CStats::IncrementStat(unsigned short, float)>:
local hook3  = eeObj.AddHook(0x2d2e54, 0x00431021, H3)	-- <CStats::IncrementStat(unsigned short, float)>:
local hook4  = eeObj.AddHook(0x2d756c, 0x3c010080, H4)	-- <CStats::UpdateSexAppealStat(void)>:
local hook5  = eeObj.AddHook(0x2d713c, 0x44030000, H5)	-- <CStats::UpdateRespectStat(unsigned char)>:
local hook6  = eeObj.AddHook(0x1fdfb8, 0x27a500c0, H6)	-- <CRunningScript::ProcessCommands100To199(int)>:
local hook7  = eeObj.AddHook(0x3045e0, 0x27bdffe0, H7)	-- <CCutsceneMgr::LoadCutsceneData(char const *)>:
local hook8  = eeObj.AddHook(0x4f31bc, 0x00711021, H8)	-- <CShopping::Buy(unsigned int, int)>:
local hook9  = eeObj.AddHook(0x2d2ff0, 0x3082ffff, H9)	-- <CStats::SetNewRecordStat(unsigned short, float)>:
local hook10 = eeObj.AddHook(0x2d3040, 0x3082ffff, H10)	-- <CStats::SetStatValue(unsigned short, float)>:
local hook11 = eeObj.AddHook(0x2e8430, 0x0080982d, H11)	-- <CGarages::TriggerMessage(char *, short, unsigned short, short)>:
local hook12 = eeObj.AddHook(0x51f078, 0x24051194, H12)	-- <CGangWars::Update(void)>:
local hook13 = eeObj.AddHook(0x331944, 0xac880000, H13)	-- <CRunningScript::ProcessCommands1100To1199(int)>:
local hook14 = eeObj.AddHook(0x3f56f0, 0x38420001, H14)	-- <CEventHandler::ComputeDamageResponse(CEvent *, CTask *, CTask *, CTask *)>:
local hook15 = eeObj.AddHook(0x2b5214, 0x30020001, H15)	-- <CTrain::ProcessControl(void)>:
local hook16 = eeObj.AddHook(0x1fc278, 0x8e030000, H16)	-- <CRunningScript::ProcessCommands0To99(int)>:
local hook17 = eeObj.AddHook(0x27bfb4, 0xae24002c, H17)	-- <CWanted::UpdateWantedLevel(void)>:
local hook18 = eeObj.AddHook(0x3194f8, 0x27a500b0, H18)	-- <CRunningScript::ProcessCommands400To499(int)>:
local hook19 = eeObj.AddHook(0x524b00, 0x00641825, H19)	-- <CRunningScript::ProcessCommands2200To2299(int)>:

-- overlays need special handling
local ov1h1 = nil

local OverlayHook =
	function()
		local namePtr = eeObj.GetGpr(gpr.a0)
		local name = eeObj.ReadMemStr(namePtr)

		if name == "credits.nm" then
			if ov1h1 == nil then
				ov1h1 = eeObj.AddHook(0x895234, 0xa3800ff8, O1H1)	-- <CCredits::RenderCredits()>:
			end
		else
			if ov1h1 ~= nil then
				eeObj.RemoveHook(ov1h1)
				ov1h1 = nil
			end
		end
	end

local ovrly = eeObj.AddHook(0x3c6bd0, 0x0080a02d, OverlayHook)	-- <mwLoadOverlay>:



-- Credits

-- Trophy design and development by SCEA ISD SpecOps
-- David Thach Senior Director
-- George Weising Executive Producer
-- Tim Lindquist Senior Technical PM
-- Clay Cowgill Engineering
-- Nicola Salmoria Engineering
-- Jenny Murphy Producer
-- David Alonzo Assistant Producer
-- Tyler Chan Associate Producer
-- Karla Quiros Manager Business Finance & Ops
-- Special thanks to A-R&D
